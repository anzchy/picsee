Picsee unsupported non-image ZIP container fixture.
